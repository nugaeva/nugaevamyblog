﻿<?php 

//Admin Panel Giriş Bilgileri ----------------
 $kadi="admin"; //Kullanıcı Adı Bilgisi tırnak işareti İçerisini Değiştirin.
 $Sifre="admin"; //Şifre Bilgisi tırnak işareti İçerisini Değiştirin.
 //---------------------------------------------
 
try {

//Db Bilgileridir Sadece burdaki bilgileri değiştirin.
//dbname: Nugaevamyblog
//nugaeva
//imti123a
	// By Coded Wod-Hack
	$Db=new PDO("mysql:host=localhost;dbname=facebook;charset=utf8",'root','hakan1207');

	
} catch (PDOExpception $e) 

{
	echo $e->getMessage();
}


?>